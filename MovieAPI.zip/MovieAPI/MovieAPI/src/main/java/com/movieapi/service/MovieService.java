package com.movieapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieapi.model.Movie;
import com.movieapi.repository.MovieRepository;

@Service
public class MovieService {

	    @Autowired
	    private MovieRepository movieRepository;

	    public List<Movie> getAllMovies() {
	        return movieRepository.findAll();
	    }

	    public Movie getMovieById(int id) {
	        return movieRepository.findById(id).orElse(null);
	    }

	    public Movie createMovie(Movie movie) {
	        return movieRepository.save(movie);
	    }

	    public Movie updateMovie(int id, Movie movie) {
	        if (movieRepository.existsById(id)) {
	            movie.setId(id);
	            return movieRepository.save(movie);
	        }
	        return null;
	    }

	    public void deleteMovie(int id) {
	        movieRepository.deleteById(id);
	    }
	
}
