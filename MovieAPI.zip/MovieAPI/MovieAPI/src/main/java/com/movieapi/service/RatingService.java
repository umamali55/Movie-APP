package com.movieapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieapi.model.MovieTypes;
import com.movieapi.model.Rating;
import com.movieapi.repository.RatingRepository;

@Service
public class RatingService {

	@Autowired
    private RatingRepository RatingRepository;

    public List<Rating> getAllRatings() {
        return RatingRepository.findAll();
    }

    public Rating getRatingById(int id) {
        return RatingRepository.findById(id).orElse(null);
    }

    public Rating createRatings(Rating rating) {
        return RatingRepository.save(rating);
    }

    public Rating updateRating(int id, Rating rating) {
        if (RatingRepository.existsById(id)) {
            rating.setId(id);
            return RatingRepository.save(rating);
        }
        return null;
    }

    public void deleteRating(int id) {
    	RatingRepository.deleteById(id);
    }
	
}
