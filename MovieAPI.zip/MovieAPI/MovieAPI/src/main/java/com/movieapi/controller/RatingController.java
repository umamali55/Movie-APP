package com.movieapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.movieapi.model.Rating;
import com.movieapi.service.RatingService;


	@RestController
	@RequestMapping("/rating")
	public class RatingController {

		@Autowired
	    private RatingService ratingService;

	    @GetMapping
	    public List<Rating> getAllRating() {
	        return ratingService.getAllRatings();
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<Rating> getratingById(@PathVariable int id) {
	        Rating rating = ratingService.getRatingById(id);
	        if (rating != null) {
	            return ResponseEntity.ok().body(rating);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }

	    @PostMapping("/save")
	    public ResponseEntity<Rating> createRating(@RequestBody Rating rating) {
	        Rating createdRating = ratingService.createRatings(rating);
	        return ResponseEntity.status(HttpStatus.CREATED).body(createdRating);
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<Rating> updateRating(@PathVariable int id, @RequestBody Rating rating) {
	        Rating updatedRating = ratingService.updateRating(id, rating);
	        if (updatedRating != null) {
	            return ResponseEntity.ok().body(updatedRating);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteMovie(@PathVariable int id) {
	        ratingService.deleteRating(id);
	        return ResponseEntity.noContent().build();
	    }
	
}
