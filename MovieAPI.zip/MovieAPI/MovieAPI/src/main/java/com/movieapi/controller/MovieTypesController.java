package com.movieapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.movieapi.model.MovieTypes;
import com.movieapi.service.MovieTypesService;

@RestController
@RequestMapping("/movietypes")
public class MovieTypesController {


	@Autowired
    private MovieTypesService movietypesService;

    @GetMapping
    public List<MovieTypes> getAllMovies() {
        return movietypesService.getAllMovies();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MovieTypes> getMovieTypesById(@PathVariable int id) {
        MovieTypes movieTypes = movietypesService.getMovieById(id);
        if (movieTypes != null) {
            return ResponseEntity.ok().body(movieTypes);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/save")
    public ResponseEntity<MovieTypes> createMovieTypes(@RequestBody MovieTypes movieTypes) {
        MovieTypes createdMovieTypes = movietypesService.createMovie(movieTypes);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdMovieTypes);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MovieTypes> updateMovieTypes(@PathVariable int id, @RequestBody MovieTypes movieTypes) {
        MovieTypes updatedMovieTypes = movietypesService.updateMovieTypes(id, movieTypes);
        if (updatedMovieTypes != null) {
            return ResponseEntity.ok().body(updatedMovieTypes);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMovieTypes(@PathVariable int id) {
    	movietypesService.deleteMovie(id);
        return ResponseEntity.noContent().build();
    }
	
}
