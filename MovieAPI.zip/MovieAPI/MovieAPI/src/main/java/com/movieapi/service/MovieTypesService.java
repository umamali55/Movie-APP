package com.movieapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.movieapi.model.MovieTypes;
import com.movieapi.repository.MovieTypesRepository;

@Service
public class MovieTypesService {

	 @Autowired
	    private MovieTypesRepository movieTypesRepository;

	    public List<MovieTypes> getAllMovies() {
	        return movieTypesRepository.findAll();
	    }

	    public MovieTypes getMovieById(int id) {
	        return movieTypesRepository.findById(id).orElse(null);
	    }

	    public MovieTypes createMovie(MovieTypes movieTypes) {
	        return movieTypesRepository.save(movieTypes);
	    }

	    public MovieTypes updateMovieTypes(int id, MovieTypes movieTypes) {
	        if (movieTypesRepository.existsById(id)) {
	            movieTypes.setId(id);
	            return movieTypesRepository.save(movieTypes);
	        }
	        return null;
	    }

	    public void deleteMovie(int id) {
	        movieTypesRepository.deleteById(id);
	    }
	
}
